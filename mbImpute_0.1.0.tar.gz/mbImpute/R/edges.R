#' @title edges of phylogenetic tree of Karlsson et al.
#'
#' @description The edges for 344 taxa
#'
#' @format A data frame containing 145 rows and 12 columns, the first column indicates the condition we are interested in.
#' \describe{
#' \item{x}{1}
#' \item{y}{2}
#' }
"edges"
