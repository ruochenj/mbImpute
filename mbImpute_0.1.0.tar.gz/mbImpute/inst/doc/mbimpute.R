## ------------------------------------------------------------------------
library(mbImpute)
# the OTU table
otu_tab[1:6, 1:6]
# the taxa distance matrix generated from phylogenetic tree 
D[1:6, 1:6]
# a numeric meta data corresponding to the otu table
meta_data[1:6, 1:6]
# get the condition from the meta data
condition = meta_data$study_condition
cond <- as.numeric(as.factor(condition))
meta_data[,1] <- as.numeric(as.factor(meta_data[,1]))
meta_data <- meta_data[,-1]

# imputed_matrix <- mbImpute(condition = condition, otu_tab = otu_tab, meta_data = meta_data, D = D, k =5)
# imputed_matrix <- mbImpute(condition = condition, otu_tab = otu_tab, meta_data = meta_data, D = D, k =5, parallel = TRUE, ncores = 4)

